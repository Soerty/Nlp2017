# -*- coding: utf-8 -*-

import nltk
from nltk.collocations import *
from nltk.metrics.spearman import *
from scipy.stats import spearmanr

gold_stand = [('суд','признать'), ('суд','начаться'), ('вынести','приговор'), 
                ('удовлетворить','иск'), ('удовлетворить','ходатайство'), 
                ('удовлетворить','ходатайство'), ('отклонить','ходатайство'), ('сообщить','адвокат'), 
                ('обжаловать','приговор'), ('санкционировать','арест')]


def parse_file(file='court-V-N.csv'):
    
    documents = []
    with open(file, encoding="utf8") as collocations:
        for line in collocations:
            line_splited = line.split()
            line = ' '.join(line_splited)
            line = line.lower().replace(',', '').replace('\n', '').replace('  ', ' ')
            line_arr = line.split()
            documents.append(line_arr)     
    
    return documents


# likelihood_ratio

def method1():
    
    finder = BigramCollocationFinder.from_documents(documents)    # Выделяем биграммы
    finder.apply_freq_filter(3)                                   # Применяем фильтр частотности от 3х повторений
    top_lr = finder.nbest(nltk.collocations.BigramAssocMeasures().likelihood_ratio, 10) # Топ 10 по метрике lr   
    spearman(top_lr)
 

# jaccard

def method2():
   
    finder = BigramCollocationFinder.from_documents(documents)
    finder.apply_freq_filter(3)
    top_jc = finder.nbest(nltk.collocations.BigramAssocMeasures().poisson_stirling, 10) # Топ 10 по метрике jaccard
    spearman(top_jc)


def spearman(result):
   
    print('Золотой стандарт:', list(ranks_from_sequence(gold_stand)))
    print('Полученный список:', list(ranks_from_sequence(result)))
    print('Коэффициент корреляции Спирмана равен %0.1f' % spearman_correlation(list(ranks_from_sequence(gold_stand)),
                                                                               list(ranks_from_sequence(result))))

if __name__ == '__main__':
    
    documents = parse_file()
    print("Метод likelihood: \n ");
    method1()
    print();
    print("Метод jaccard: \n ");
    method2()
    print();
    print("Были использованы два метода с разными метриками, с jaccard И likelihood  \n" +
        + " Путем беглого просмотра был подобран золотой стандарт. Расчет коэффициента корреляции \n" +
        + " Для likelihood положительный, и больше похож на правду.");
    print("Рассчет коэффициента корреляции, для jaccard, отрицательный и далек от истины. ");
    print("Для метрики likelihood, корреляция более верная и близка к правде.");

